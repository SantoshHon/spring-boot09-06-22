package com.mindgate.main.repository;



import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import com.mindgate.main.pojo.EmployeeDetails;

public interface EmployeeDetailsRepositoryInterface {
	public boolean addEmployeeDetails(EmployeeDetails employeeDetails);
	//public boolean updateEmployeeDetails(EmployeeDetails employeeDetails);
	//public boolean deleteEmployeeDetailsByemployeeDetailsId(int employeeDetailsId);
	public EmployeeDetails getEmployeeDetailsByemployeeDetailsId(int employeeDetailsId);
	public List<EmployeeDetails>getAllEmployeeDetails();
	public EmployeeDetails getEmployeeDetailsByLoginId(int loginid) ;

}
